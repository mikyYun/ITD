-- 11. rename all the columns under the film table
-- SELECT * FROM film;

-- ALTER TABLE film
-- 	RENAME COLUMN title
-- 	TO film_title; 

-- ALTER TABLE film
-- 	RENAME COLUMN description
-- 	TO film_description;
	
-- ALTER TABLE film
-- 	RENAME COLUMN release_year
-- 	TO released_year;
	
-- ALTER TABLE film
-- 	RENAME COLUMN rental_duration
-- 	TO duration;
	
-- ALTER TABLE film
-- 	RENAME COLUMN rental_rate
-- 	TO rate;
	
-- ALTER TABLE film
-- 	RENAME COLUMN length
-- 	TO running_time;
	
-- ALTER TABLE film
-- 	RENAME COLUMN replacement_cost
-- 	TO replcaement_fee;
	
-- ALTER TABLE film
-- 	RENAME COLUMN rating
-- 	TO film_rating;
	
-- ALTER TABLE film
-- 	RENAME COLUMN last_update
-- 	TO latest_update;
	
-- ALTER TABLE film
-- 	RENAME COLUMN special_features
-- 	TO features;

-- ALTER TABLE film
-- 	RENAME COLUMN fulltext
-- 	TO text;
	
-- 12. find 4-digit postal codes under the address table
SELECT postal_code FROM address
	WHERE postal_code <> ''
		AND CAST(postal_code AS DECIMAL) >= 1000
		AND CAST(postal_code AS DECIMAL) < 10000;
		
-- 13. find all the 5 digit postal codes starting with 4 or 5 or 6 and only return max 10 rows
SELECT postal_code FROM address
	WHERE postal_code <> ''
		AND CAST(postal_code AS DECIMAL) >= 40000
		AND CAST(postal_code AS DECIMAL) < 70000
		LIMIT 10;
		
-- 14. create a merged column containing language id and language separated with a comma.
--  AND organize it in two ways
-- 		1. by language id, 
SELECT CONCAT(language.name, ', ', language.language_id) FROM language
	ORDER BY language_id;

-- 	 	2. by language column aplhabetically
SELECT CONCAT(language.name, ', ', language.language_id) FROM language
	ORDER BY language.name;
	
-- 15. find all the first name starting with "D" to including "H"
-- with BETWEEN
SELECT first_name FROM actor
	WHERE first_name BETWEEN 'D' AND 'I'
	ORDER BY first_name;
	
-- with comparison
SELECT first_name FROM actor
	WHERE first_name >= 'D%'
		AND first_name < 'I'
	ORDER BY first_name;
	
-- 16. create merged column to generate with the format 'lastname_firstname@ID'
SELECT CONCAT(last_name, '_', first_name, '@', actor_id) AS full_name_with_id FROM actor
	WHERE first_name >= 'L';
	
-- 17. find people who have first names are 'Ben' || 'Bob' || 'Allen' and count each
--  then find last name is 'Brown' from the table and counting them(Brown)
UPDATE actor
	SET last_name = 'Brown'
	WHERE first_name IN ('Ben', 'Bob', 'Allen');

SELECT first_name, COUNT(first_name) FROM actor
	WHERE first_name IN ('Ben', 'Bob', 'Allen')
	GROUP BY first_name;
	
SELECT last_name, COUNT(last_name) FROM actor
	WHERE last_name = 'Brown'
	GROUP BY last_name;